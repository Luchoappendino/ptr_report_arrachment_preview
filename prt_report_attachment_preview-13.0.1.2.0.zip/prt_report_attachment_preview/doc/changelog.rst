13.0.1.2.0
-----------

- *Bugfix* printing report via button doesn't 'freeze' form any more

13.0.1.0
-----------

- Release for Odoo 13
